const form = document.getElementById("supportForm");
const status = document.getElementById("status");

form.addEventListener("submit", (e) => {
  e.preventDefault();
  const phone = document.getElementById("phone").value.trim();
  const reason = document.getElementById("reason").value;

  if (!phone) return;
  status.textContent =
    `Demande préparée pour ${phone} — motif : ${reason}. Aucun bannissement automatique n'est effectué.`;
});
