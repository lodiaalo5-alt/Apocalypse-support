# S.K.7 ♻️ — Support BAN / UNBAN

Interface statique inspirée de la maquette fournie.

## Mise en ligne avec GitHub Pages

1. Crée un dépôt GitHub, par exemple `sk7-support`.
2. Ajoute `index.html`, `style.css` et `script.js` à la racine du dépôt.
3. Ouvre **Settings → Pages**.
4. Dans **Build and deployment**, choisis **Deploy from a branch**.
5. Choisis la branche `main` et le dossier `/ (root)`.
6. Enregistre puis attends la publication de GitHub Pages.

### Important
Cette version est uniquement une interface de support. Le bouton **ENVOYER** ne bannit personne et n'envoie pas automatiquement de signalements en masse.
